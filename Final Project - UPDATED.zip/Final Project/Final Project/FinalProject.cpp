/*
Author: Jordan Mitchell
Date: 2/22/24
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>
#include <thread> // For std::this_thread::sleep_for

using namespace std;

// Structure for holding course info
struct Course {

    string courseNum;
    string courseTitle;
    vector<string> preList;
};

class BinarySearchTree {
    // Structs for holding courses
    struct Node {
        Course course;
        Node* right;
        Node* left;

        // constructor
        Node() {
            left = nullptr;
            right = nullptr;
        }

        // initialize with oneCourse
        Node(Course oneCourse) {
            course = oneCourse;
            left = nullptr;
            right = nullptr;
        }
    };
    Node* root;
    void inOrder(Node* node);
    int size = 0;

public:
    BinarySearchTree();
    void InOrder();
    void Insert(Course oneCourse);
    void Remove(string courseNum);
    Course Search(string courseNum);
    int Size();
};

// Constructor
BinarySearchTree::BinarySearchTree() {
    this->root = nullptr;
}

// search tree in order
void BinarySearchTree::InOrder() {
    inOrder(root);
}
// Convert all strings to uppercase
void convertCase(string& toConvert) {

    for (unsigned int i = 0; i < toConvert.length(); i++) {

        if (isalpha(toConvert[i])) {

            toConvert[i] = toupper(toConvert[i]);
        }
    }
}
// Insert course
void BinarySearchTree::Insert(Course oneCourse) {

    Node* currNode = root;

    if (root == NULL) {

        root = new Node(oneCourse);

    }
    else {

        while (currNode != NULL) {

            if (oneCourse.courseNum < currNode->course.courseNum) {

                if (currNode->left == nullptr) {

                    currNode->left = new Node(oneCourse);
                    currNode = NULL;
                }
                else {

                    currNode = currNode->left;
                }
            }
            else {

                if (currNode->right == nullptr) {

                    currNode->right = new Node(oneCourse);
                    currNode = NULL;
                }
                else {

                    currNode = currNode->right;
                }
            }
        }
    }
    size++;
}

// Search course
Course BinarySearchTree::Search(string courseNum) {
    Course oneCourse;

    Node* currNode = root;

    // Convert courseNum to uppercase
    convertCase(courseNum);

    while (currNode != NULL) {
        // Convert course ID to uppercase before comparison
        string currentNodeCourseNum = currNode->course.courseNum;
        convertCase(currentNodeCourseNum);

        if (currentNodeCourseNum == courseNum) {
            return currNode->course;
        }
        else if (courseNum < currentNodeCourseNum) {
            currNode = currNode->left;
        }
        else {
            currNode = currNode->right;
        }
    }

    // if not found
    // Print "Value not found." 
    return oneCourse;
}

void BinarySearchTree::inOrder(Node* node) {

    if (node == NULL) {

        return;
    }
    inOrder(node->left);

    // print node
    cout << node->course.courseNum << ", " << node->course.courseTitle << endl;

    inOrder(node->right);
}

int BinarySearchTree::Size() {

    return size;
}

// split string by delimiter
vector<string> Split(string lineFeed) {

    char delim = ',';
    // delimiter at end so last word is also read
    lineFeed += delim; 
    vector<string> lineTokens;
    string temp = "";
    for (int i = 0; i < lineFeed.length(); i++)
    {
        if (lineFeed[i] == delim)
        {
            //store words in vector token
            lineTokens.push_back(temp); 
            temp = "";
            i++;
        }
        temp += lineFeed[i];
    }
    return lineTokens;
}
// func for loading courses
void loadCourses(string csvPath, BinarySearchTree* courseList) {
    // Create a data struc then add to courses 
     //instream for reading file
    ifstream inFS;
    //line feed 
    string line;
    vector<string> stringTokens;
    //open read file
    inFS.open(csvPath);
    // error handler
    if (!inFS.is_open()) {
        cout << "File can't be opened. Please enter new input. " << endl;
        return;
    }

    // Check for BOM and skip it if present
    char bom[3] = { 0xEF, 0xBB, 0xBF };
    char firstChars[3] = { 0 };
    inFS.read(firstChars, 3);
    if (strncmp(firstChars, bom, 3) != 0) {
        // BOM not present, reset file pointer
        inFS.seekg(0);
    }
    else {
        // BOM present, skip it
        inFS.seekg(3);
    }

    while (!inFS.eof()) {
        // create new struct for each line
        Course oneCourse;

        getline(inFS, line);
        // split line into tokens with delimiter
        stringTokens = Split(line);
        // if less than 2 tokens, line is not formatted properly
        if (stringTokens.size() < 2) {

            cout << "\nError. Skipping line." << endl;
        }

        else {

            oneCourse.courseNum = stringTokens.at(0);
            oneCourse.courseTitle = stringTokens.at(1);

            for (unsigned int i = 2; i < stringTokens.size(); i++) {

                oneCourse.preList.push_back(stringTokens.at(i));
            }

            // move course to end
            courseList->Insert(oneCourse);
        }
    }
    //close file
    inFS.close();
}


// Print courseNum, courseTitle, and preReq Count

void displayCourse(Course oneCourse) {

    cout << oneCourse.courseNum << ", " << oneCourse.courseTitle << endl;
    cout << "Prerequisites: ";
    //if list is empty then no prereqs
    if (oneCourse.preList.empty()) {

        cout << "none" << endl;
    }
    else {

        for (unsigned int i = 0; i < oneCourse.preList.size(); i++) {

            cout << oneCourse.preList.at(i);
            // place comma for any elements > 1
            if (oneCourse.preList.size() > 1 && i < oneCourse.preList.size() - 1) {

                cout << ", ";
            }
        }
    }

    cout << endl;
}

int main(int argc, char* argv[]) {

    // for command line arguments
    string csvPath, oneCourseKey;

    switch (argc) {
    case 2:
        csvPath = argv[1];
        break;
    case 3:
        csvPath = argv[1];
        oneCourseKey = argv[2];
        break;
    default:
        csvPath = "FinalProject_course_list.csv";
    }
    // Define table to hold all courses
    BinarySearchTree* courseList = new BinarySearchTree();

    Course course;
    bool validInput;
    int choice = 0;

    while (choice != 9) {
        cout << "Welcome to the course planner:" << endl;
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Find Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "What would you like to do? Enter choice: ";

        // empty the strings
        oneCourseKey = "";         
        string anyKey = " ";
        // empty the choice
        choice = 0; 
        
        try {
            cin >> choice;
            // limit input to valid values
            if ((choice > 0 && choice < 4) || (choice == 9)) {
                validInput = true;
            }
            else {
                //throw error for catch
                validInput = false;
                throw 1;
            }

            switch (choice) {
            case 1:

                // Complete the method call to load the courses
                loadCourses(csvPath, courseList);
                cout << courseList->Size() << " courses read" << endl;

                // delay after loading the courses
                std::this_thread::sleep_for(std::chrono::seconds(2));

                break;

            case 2:
                courseList->InOrder();

                cout << "\nEnter \'y\' to continue..." << endl;

                cin >> anyKey;

                break;

            case 3:

                cout << "\nWhat course do you want to know about? " << endl;
                cin >> oneCourseKey;
                //convert case of user input
                convertCase(oneCourseKey); 

                course = courseList->Search(oneCourseKey);

                if (!course.courseNum.empty()) {
                    displayCourse(course);
                }
                else {
                    cout << "\nCourse ID " << oneCourseKey << " not found." << endl;
                }

                // delay after searching for a course
                std::this_thread::sleep_for(std::chrono::seconds(4));

                break;
            case 9:
                exit;
                break;

            default:

                throw 2;
            }
        }

        catch (int err) {

            std::cout << "\nInvalid input, try again." << endl;
            // delay after catching an invalid input
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }

        // clears the operator of input or any error created by bad input
        cin.clear();
        cin.ignore();

        // clears consolse and brings up new menu
        system("cls");
    }

    cout << "Exiting now." << endl;

    // delay before exiting the program
    std::this_thread::sleep_for(std::chrono::seconds(1));

    return 0;
}